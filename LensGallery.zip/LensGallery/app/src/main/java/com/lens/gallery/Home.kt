package com.lens.gallery

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.Collections
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun Home(vm: GalleryVM, onOpen: (List<Media>, Int) -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var album by rememberSaveable { mutableStateOf<String?>(null) }
    BackHandler(album != null) { album = null }
    val tabs = listOf(
        "Photos" to Icons.Outlined.PhotoLibrary,
        "Albums" to Icons.Outlined.Collections,
        "Favorites" to Icons.Outlined.FavoriteBorder,
    )
    Scaffold(
        containerColor = Ink,
        bottomBar = {
            NavigationBar(containerColor = Panel) {
                tabs.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i; album = null },
                        icon = { Icon(icon, label) },
                        label = { Text(label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black, indicatorColor = Orange,
                        ),
                    )
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (tab == 1 && album == null) {
                Albums(vm.items) { album = it }
            } else {
                val list = when {
                    tab == 2 -> vm.items.filter { it.uri.toString() in vm.favs }
                    album != null -> vm.items.filter { it.album == album }
                    else -> vm.items
                }
                Grid(list, onOpen)
            }
        }
    }
}

@Composable
fun Grid(list: List<Media>, onOpen: (List<Media>, Int) -> Unit) {
    if (list.isEmpty()) {
        Box(Modifier.fillMaxSize(), Alignment.Center) { Text("Nothing here yet", color = Color.Gray) }
        return
    }
    val fmt = remember { SimpleDateFormat("EEE, d MMM yyyy", Locale.getDefault()) }
    val groups = remember(list) { list.withIndex().groupBy { fmt.format(Date(it.value.dateMs)) } }
    LazyVerticalGrid(
        columns = GridCells.Adaptive(110.dp),
        contentPadding = PaddingValues(2.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        groups.forEach { (day, entries) ->
            item(key = "h$day", span = { GridItemSpan(maxLineSpan) }) {
                Text(
                    day, color = Color(0xFFBBBBBB), fontSize = 13.sp,
                    modifier = Modifier.padding(start = 10.dp, top = 14.dp, bottom = 6.dp),
                )
            }
            items(entries, key = { it.value.uri.toString() }) { (idx, m) ->
                Thumb(m, Modifier.aspectRatio(1f)) { onOpen(list, idx) }
            }
        }
    }
}

@Composable
fun Thumb(m: Media, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val ctx = LocalContext.current
    Box(modifier.background(Panel).clickable(onClick = onClick)) {
        AsyncImage(
            model = ImageRequest.Builder(ctx).data(m.uri).size(300).build(),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
        )
        if (m.isVideo) {
            Row(
                Modifier.align(Alignment.BottomStart).padding(4.dp)
                    .clip(RoundedCornerShape(6.dp)).background(Color(0x99000000)).padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.PlayArrow, null, Modifier.size(14.dp), tint = Color.White)
                val s = m.durationMs / 1000
                Text("%d:%02d".format(s / 60, s % 60), color = Color.White, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun Albums(all: List<Media>, onPick: (String) -> Unit) {
    val groups = remember(all) { all.groupBy { it.album }.toList().sortedByDescending { it.second.size } }
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        contentPadding = PaddingValues(10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        items(groups, key = { it.first }) { (name, list) ->
            Column(Modifier.clickable { onPick(name) }) {
                Thumb(list.first(), Modifier.aspectRatio(1f).clip(RoundedCornerShape(14.dp))) { onPick(name) }
                Text(name, color = Color.White, modifier = Modifier.padding(top = 6.dp), maxLines = 1)
                Text("${list.size}", color = Color.Gray, fontSize = 12.sp)
            }
        }
    }
}
