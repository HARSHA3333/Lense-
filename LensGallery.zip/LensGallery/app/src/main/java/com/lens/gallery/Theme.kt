package com.lens.gallery

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Orange = Color(0xFFFF6A00)
val Ink = Color(0xFF0A0A0A)
val Panel = Color(0xFF151515)

@Composable
fun LensTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(
        primary = Orange, background = Ink, surface = Panel,
        onBackground = Color.White, onSurface = Color.White,
    ),
    content = content,
)
