package com.lens.gallery

import android.content.ContentValues
import android.content.Context
import android.graphics.*
import android.net.Uri
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.exifinterface.media.ExifInterface
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max

fun colorMatrixArray(brightness: Float, contrast: Float, saturation: Float): FloatArray {
    val t = 127.5f * (1 - contrast) + brightness
    val con = ColorMatrix(
        floatArrayOf(
            contrast, 0f, 0f, 0f, t,
            0f, contrast, 0f, 0f, t,
            0f, 0f, contrast, 0f, t,
            0f, 0f, 0f, 1f, 0f,
        )
    )
    return ColorMatrix().apply { setSaturation(saturation); postConcat(con) }.array
}

@Composable
fun Editor(m: Media, onDone: (saved: Boolean) -> Unit) {
    BackHandler { onDone(false) }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var rot by remember { mutableIntStateOf(0) }
    var br by remember { mutableFloatStateOf(0f) }
    var ct by remember { mutableFloatStateOf(1f) }
    var sat by remember { mutableFloatStateOf(1f) }
    var saving by remember { mutableStateOf(false) }
    val cm = remember(br, ct, sat) { colorMatrixArray(br, ct, sat) }

    Column(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ onDone(false) }) { Icon(Icons.Filled.Close, "Cancel", tint = Color.White) }
            Spacer(Modifier.weight(1f))
            IconButton({ rot = (rot + 90) % 360 }) { Icon(Icons.Filled.RotateRight, "Rotate", tint = Color.White) }
            TextButton(
                enabled = !saving,
                onClick = {
                    saving = true
                    scope.launch {
                        val ok = withContext(Dispatchers.IO) { runCatching { saveEdited(ctx, m.uri, rot, cm) }.isSuccess }
                        saving = false
                        Toast.makeText(ctx, if (ok) "Saved to Pictures/Lens" else "Save failed", Toast.LENGTH_SHORT).show()
                        if (ok) onDone(true)
                    }
                },
            ) { Text(if (saving) "Saving…" else "Save copy", color = Orange) }
        }
        Box(Modifier.weight(1f).fillMaxWidth(), Alignment.Center) {
            AsyncImage(
                model = m.uri, contentDescription = null, contentScale = ContentScale.Fit,
                colorFilter = ColorFilter.colorMatrix(androidx.compose.ui.graphics.ColorMatrix(cm)),
                modifier = Modifier.fillMaxSize().rotate(rot.toFloat()),
            )
        }
        Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
            EditSlider("Brightness", br, -80f..80f) { br = it }
            EditSlider("Contrast", ct, 0.6f..1.5f) { ct = it }
            EditSlider("Saturation", sat, 0f..2f) { sat = it }
        }
    }
}

@Composable
private fun EditSlider(label: String, v: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.Gray, modifier = Modifier.width(90.dp))
        Slider(
            value = v, onValueChange = onChange, valueRange = range,
            colors = SliderDefaults.colors(thumbColor = Orange, activeTrackColor = Orange),
        )
    }
}

/** Saves an edited COPY to Pictures/Lens. Large photos are downscaled to 4096px to avoid out-of-memory crashes. */
fun saveEdited(ctx: Context, uri: Uri, rot: Int, cm: FloatArray) {
    val r = ctx.contentResolver
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    r.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (max(bounds.outWidth, bounds.outHeight) / sample > 4096) sample *= 2
    val src = r.openInputStream(uri)!!.use {
        BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
    }!!
    val exifRot = r.openInputStream(uri)!!.use { ExifInterface(it).rotationDegrees }
    val matrix = Matrix().apply { postRotate(((rot + exifRot) % 360).toFloat()) }
    val rotated = Bitmap.createBitmap(src, 0, 0, src.width, src.height, matrix, true)
    val out = Bitmap.createBitmap(rotated.width, rotated.height, Bitmap.Config.ARGB_8888)
    Canvas(out).drawBitmap(rotated, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(ColorMatrix(cm)) })
    val cv = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "LENS_${System.currentTimeMillis()}.jpg")
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Lens")
    }
    val dst = r.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)!!
    r.openOutputStream(dst)!!.use { out.compress(Bitmap.CompressFormat.JPEG, 95, it) }
}
