package com.lens.gallery

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { LensTheme { Root() } }
    }
}

@Composable
fun Root(vm: GalleryVM = viewModel()) {
    val ctx = LocalContext.current
    val perms = if (Build.VERSION.SDK_INT >= 33)
        arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
    else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    var granted by remember {
        mutableStateOf(perms.all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED })
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        granted = res.values.all { it }
        if (granted) vm.load()
    }
    LaunchedEffect(Unit) { if (granted) vm.load() else launcher.launch(perms) }

    var viewer by remember { mutableStateOf<Pair<List<Media>, Int>?>(null) }
    var editing by remember { mutableStateOf<Media?>(null) }

    val v = viewer
    val e = editing
    when {
        !granted -> Column(
            Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally,
        ) {
            Text("Lens needs access to your photos and videos", color = Color.White)
            Button({ launcher.launch(perms) }) { Text("Grant access") }
        }
        e != null -> Editor(e) { saved -> editing = null; if (saved) vm.load() }
        v != null -> Viewer(vm, v.first, v.second, onEdit = { editing = it }, onClose = { viewer = null })
        else -> Home(vm) { list, i -> viewer = list to i }
    }
}
