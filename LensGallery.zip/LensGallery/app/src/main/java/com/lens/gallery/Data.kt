package com.lens.gallery

import android.app.Application
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import coil.memory.MemoryCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class App : Application(), ImageLoaderFactory {
    override fun newImageLoader() = ImageLoader.Builder(this)
        .components { add(VideoFrameDecoder.Factory()) }
        .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.25).build() }
        .crossfade(120)
        .build()
}

data class Media(
    val id: Long,
    val uri: Uri,
    val isVideo: Boolean,
    val dateMs: Long,
    val album: String,
    val durationMs: Long,
)

class GalleryVM(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("lens", Context.MODE_PRIVATE)
    var items by mutableStateOf<List<Media>>(emptyList()); private set
    var favs by mutableStateOf<Set<String>>(prefs.getStringSet("favs", emptySet())!!.toSet()); private set

    fun load() {
        viewModelScope.launch { items = withContext(Dispatchers.IO) { query() } }
    }

    fun toggleFav(m: Media) {
        val k = m.uri.toString()
        favs = if (k in favs) favs - k else favs + k
        prefs.edit().putStringSet("favs", favs).apply()
    }

    private fun query(): List<Media> {
        val f = MediaStore.Files.FileColumns
        val proj = arrayOf(
            f._ID, f.MEDIA_TYPE, f.DATE_ADDED,
            MediaStore.MediaColumns.DATE_TAKEN,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
            MediaStore.MediaColumns.DURATION,
        )
        val sel = "${f.MEDIA_TYPE}=? OR ${f.MEDIA_TYPE}=?"
        val args = arrayOf(f.MEDIA_TYPE_IMAGE.toString(), f.MEDIA_TYPE_VIDEO.toString())
        val out = ArrayList<Media>()
        getApplication<Application>().contentResolver
            .query(MediaStore.Files.getContentUri("external"), proj, sel, args, "${f.DATE_ADDED} DESC")
            ?.use { c ->
                val iId = c.getColumnIndexOrThrow(f._ID)
                val iType = c.getColumnIndexOrThrow(f.MEDIA_TYPE)
                val iAdded = c.getColumnIndexOrThrow(f.DATE_ADDED)
                val iTaken = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)
                val iBucket = c.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME)
                val iDur = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DURATION)
                while (c.moveToNext()) {
                    val video = c.getInt(iType) == f.MEDIA_TYPE_VIDEO
                    val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                    else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                    val id = c.getLong(iId)
                    val taken = c.getLong(iTaken)
                    out += Media(
                        id = id,
                        uri = ContentUris.withAppendedId(base, id),
                        isVideo = video,
                        dateMs = if (taken > 0) taken else c.getLong(iAdded) * 1000,
                        album = c.getString(iBucket) ?: "Other",
                        durationMs = c.getLong(iDur),
                    )
                }
            }
        return out.sortedByDescending { it.dateMs }
    }
}
