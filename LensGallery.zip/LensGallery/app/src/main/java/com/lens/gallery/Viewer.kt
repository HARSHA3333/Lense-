package com.lens.gallery

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.exifinterface.media.ExifInterface
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Viewer(vm: GalleryVM, list: List<Media>, start: Int, onEdit: (Media) -> Unit, onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    val pager = rememberPagerState(initialPage = start) { list.size }
    var zoomed by remember { mutableStateOf(false) }
    var chrome by remember { mutableStateOf(true) }
    var showInfo by remember { mutableStateOf(false) }
    LaunchedEffect(pager.currentPage) { zoomed = false }
    val cur = list[pager.currentPage]
    val fav = cur.uri.toString() in vm.favs

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(pager, Modifier.fillMaxSize(), userScrollEnabled = !zoomed) { p ->
            val m = list[p]
            if (m.isVideo) VideoPage(m, active = pager.currentPage == p)
            else ZoomImage(m, onTap = { chrome = !chrome }, onZoom = { zoomed = it })
        }
        if (chrome) {
            Row(
                Modifier.fillMaxWidth().align(Alignment.TopCenter)
                    .background(Brush.verticalGradient(listOf(Color(0xAA000000), Color.Transparent)))
                    .statusBarsPadding().padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
                Spacer(Modifier.weight(1f))
                IconButton({ vm.toggleFav(cur) }) {
                    Icon(
                        if (fav) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, "Favorite",
                        tint = if (fav) Orange else Color.White,
                    )
                }
                IconButton({ showInfo = true }) { Icon(Icons.Filled.Info, "Info", tint = Color.White) }
                if (!cur.isVideo) IconButton({ onEdit(cur) }) { Icon(Icons.Filled.Edit, "Edit", tint = Color.White) }
            }
        }
    }
    if (showInfo) {
        ModalBottomSheet(onDismissRequest = { showInfo = false }, containerColor = Panel) {
            ExifPanel(cur)
        }
    }
}

@Composable
fun ZoomImage(m: Media, onTap: () -> Unit, onZoom: (Boolean) -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    Box(
        Modifier.fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = {
                        if (scale > 1f) { scale = 1f; offset = Offset.Zero } else scale = 2.5f
                        onZoom(scale > 1f)
                    },
                )
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val e = awaitPointerEvent()
                        if (scale > 1f || e.changes.size > 1) {
                            scale = (scale * e.calculateZoom()).coerceIn(1f, 6f)
                            offset = if (scale == 1f) Offset.Zero else offset + e.calculatePan()
                            onZoom(scale > 1f)
                            e.changes.forEach { it.consume() }
                        }
                    } while (e.changes.any { it.pressed })
                }
            },
    ) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current).data(m.uri).size(2400).build(),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize().graphicsLayer {
                scaleX = scale; scaleY = scale
                translationX = offset.x; translationY = offset.y
            },
        )
    }
}

@Composable
fun VideoPage(m: Media, active: Boolean) {
    val ctx = LocalContext.current
    val player = remember {
        ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(m.uri)); prepare() }
    }
    DisposableEffect(Unit) { onDispose { player.release() } }
    LaunchedEffect(active) { player.playWhenReady = active }
    AndroidView(
        factory = { c -> PlayerView(c).apply { this.player = player } },
        modifier = Modifier.fillMaxSize(),
    )
}

@Composable
fun ExifPanel(m: Media) {
    val ctx = LocalContext.current
    val rows = remember(m) {
        runCatching {
            ctx.contentResolver.openInputStream(m.uri)!!.use { s ->
                val e = ExifInterface(s)
                fun a(t: String) = e.getAttribute(t)
                val f = e.getAttributeDouble(ExifInterface.TAG_F_NUMBER, 0.0)
                val t = e.getAttributeDouble(ExifInterface.TAG_EXPOSURE_TIME, 0.0)
                val fl = e.getAttributeDouble(ExifInterface.TAG_FOCAL_LENGTH, 0.0)
                listOf(
                    "Camera" to listOfNotNull(a(ExifInterface.TAG_MAKE), a(ExifInterface.TAG_MODEL)).joinToString(" "),
                    "Lens" to (a(ExifInterface.TAG_LENS_MODEL) ?: ""),
                    "Aperture" to if (f > 0) "ƒ/%.1f".format(f) else "",
                    "Shutter" to when {
                        t <= 0 -> ""
                        t < 1 -> "1/${(1 / t).roundToInt()} s"
                        else -> "%.1f s".format(t)
                    },
                    "ISO" to (a(ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY) ?: ""),
                    "Focal length" to if (fl > 0) "%.0f mm".format(fl) else "",
                    "Taken" to (a(ExifInterface.TAG_DATETIME_ORIGINAL) ?: ""),
                    "Size" to "${a(ExifInterface.TAG_IMAGE_WIDTH) ?: "?"} × ${a(ExifInterface.TAG_IMAGE_LENGTH) ?: "?"}",
                ).filter { it.second.isNotBlank() && !it.second.startsWith("? ×") }
            }
        }.getOrDefault(emptyList())
    }
    Column(Modifier.padding(horizontal = 24.dp).padding(bottom = 32.dp)) {
        Text("Details", fontSize = 18.sp, color = Color.White, modifier = Modifier.padding(bottom = 12.dp))
        if (rows.isEmpty()) Text("No EXIF data", color = Color.Gray)
        rows.forEach { (k, v) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Text(k, color = Color.Gray, modifier = Modifier.width(110.dp))
                Text(v, color = Color.White)
            }
        }
    }
}
