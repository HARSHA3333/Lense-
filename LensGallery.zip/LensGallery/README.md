# Lens Gallery (Kotlin + Jetpack Compose)

Dark, minimal, Sony-style gallery. Features: date-grouped photo grid, albums, favorites,
full-screen viewer (swipe, pinch/double-tap zoom), video playback, EXIF panel
(camera, lens, aperture, shutter, ISO, focal length), basic editor (rotate, brightness,
contrast, saturation) that saves a COPY to Pictures/Lens.

## Build the APK
1. Install Android Studio (latest stable).
2. File > Open > select the LensGallery folder. Wait for Gradle sync (first sync downloads
   dependencies, needs internet).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Click "locate" in the popup: app/build/outputs/apk/debug/app-debug.apk
5. Copy the APK to your phone, open it, allow "Install unknown apps", install.
   Or plug in the phone (USB debugging on) and press Run.

Requires Android 10 (API 29) or newer.
